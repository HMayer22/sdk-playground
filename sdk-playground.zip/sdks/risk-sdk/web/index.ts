export function initSDK({ endpoint }:{ endpoint:string }){
  function autoCollect(){
    fetch(endpoint + '/api/telemetry', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ source:'web', type:'page_load', ua: navigator.userAgent, tz: Intl.DateTimeFormat().resolvedOptions().timeZone })
    }).catch(()=>{});
  }
  async function evaluate(event:string, context:any){
    // exemplo: o playground não precisa de evaluate, quem decide é o middleware
    return { decision: 'allow', score: 0, event, context };
  }
  return { autoCollect, evaluate };
}
