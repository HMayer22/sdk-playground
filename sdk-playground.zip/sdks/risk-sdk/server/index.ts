export function middleware(req:any,_res:any,next:any){
  // Exemplo: bloquear se valor do pedido é muito alto e e-mail não verificado (simulado)
  const event = req.path.includes('checkout') ? 'checkout' : (req.path.includes('login') ? 'login' : 'other');
  const ctx = req.body?.context || {};
  let score = 0;
  if (event === 'login'){
    if (ctx.failedAttempts) score += Math.min(ctx.failedAttempts*15, 45);
  }
  if (event === 'checkout'){
    const amount = Number(req.body?.amount||0);
    if (amount >= 500) score += 40;
    if (amount >= 1000) score += 70;
  }
  const decision = score >= 60 ? 'block' : (score >= 30 ? 'challenge' : 'allow');
  if (decision !== 'allow'){
    req.sdkDecision = { source: 'risk-sdk', decision, score, message: 'heurística de exemplo' };
  }
  next();
}
