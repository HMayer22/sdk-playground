# Quickstart

## 1) Dependências
- Node.js 18+
- Yarn
- (opcional) Docker Desktop

## 2) Instalar e subir serviços base
```bash
yarn
docker compose -f docker/docker-compose.yml up -d
```

## 3) Rodar API e Front
```bash
yarn dev:api
# nova aba
yarn dev:web
# opcional
yarn dev:dash
```

- Loja: http://localhost:5173 (porta padrão do Vite)
- API: http://localhost:4001/health
- Dashboard: http://localhost:4002

## 4) Testar fluxos
- Na loja, faça Login e Checkout
- Verifique as respostas (allow/challenge/block) vindas do middleware de exemplo (`sdks/risk-sdk/server/index.ts`)
- Veja os eventos no Dashboard
