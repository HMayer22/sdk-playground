import express from 'express';
import fetch from 'node-fetch';

const app = express();
const API = process.env.API_URL || 'http://localhost:4001';

app.get('/', async (_req,res)=>{
  const logs = await fetch(API + '/api/logs').then(r=>r.json()).catch(()=>[]);
  res.send(`
    <html><head><title>SDK Dashboard</title></head>
    <body style="font-family:sans-serif; padding:20px">
      <h1>SDK Dashboard</h1>
      <p>API: ${API}</p>
      <h3>Últimos eventos</h3>
      <pre style="background:#f5f5f5; padding:10px; max-height:70vh; overflow:auto">${JSON.stringify(logs,null,2)}</pre>
    </body></html>
  `);
});

const port = Number(process.env.PORT || 4002);
app.listen(port, ()=> console.log(`[dashboard] http://localhost:${port}`));
