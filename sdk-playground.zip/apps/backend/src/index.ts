import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { Pool } from 'pg';
import { createClient } from 'redis';
import fs from 'fs';
import path from 'path';
import { z } from 'zod';
import winston from 'winston';

const app = express();
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());

const port = Number(process.env.PORT || 4001);
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const redis = createClient({ url: process.env.REDIS_URL });
redis.connect().catch(()=>{});

const logger = winston.createLogger({
  level: 'info',
  transports: [ new winston.transports.Console() ],
  format: winston.format.json()
});

// Ensure tables (simple)
async function initDb(){
  await pool.query(`
    CREATE TABLE IF NOT EXISTS sdk_events (
      id SERIAL PRIMARY KEY,
      ts TIMESTAMP DEFAULT NOW(),
      source VARCHAR(50),
      type VARCHAR(50),
      data JSONB
    );
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      email TEXT UNIQUE,
      password TEXT,
      created_at TIMESTAMP DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS orders (
      id SERIAL PRIMARY KEY,
      user_email TEXT,
      amount NUMERIC,
      created_at TIMESTAMP DEFAULT NOW()
    );
  `);
}
initDb().catch(console.error);

// SDK server middlewares loader
const sdkServerDir = path.join(process.cwd(), 'sdks');
const sdkMiddlewares: Array<(req:any,res:any,next:any)=>void> = [];
if (fs.existsSync(sdkServerDir)){
  for (const dir of fs.readdirSync(sdkServerDir)){
    const p = path.join(sdkServerDir, dir, 'server', 'index.ts');
    const pj = path.join(sdkServerDir, dir, 'server', 'index.js');
    const file = fs.existsSync(pj) ? pj : (fs.existsSync(p) ? p : null);
    if (file){
      try {
        const mod = require(file);
        if (typeof mod.middleware === 'function'){
          sdkMiddlewares.push(mod.middleware);
          console.log(`[sdk] loaded middleware from ${dir}`);
        }
      } catch (e){
        console.warn(`[sdk] failed to load ${dir}:`, e);
      }
    }
  }
}

// Helpers
function applySdkMiddlewares(req:any,res:any, next:any){
  let i = 0;
  function run(){
    if (i >= sdkMiddlewares.length) return next();
    const mw = sdkMiddlewares[i++];
    mw(req,res,run);
  }
  run();
}

// Routes
app.get('/health', (_req,res)=> res.json({ ok: true }));

app.post('/api/telemetry', async (req,res)=>{
  const { source='web', type='event', ...rest } = req.body || {};
  await pool.query('INSERT INTO sdk_events(source,type,data) VALUES ($1,$2,$3)', [source, type, rest]);
  logger.info({ source, type, rest });
  res.json({ ok: true });
});

const LoginSchema = z.object({ email: z.string().email(), password: z.string().min(3) });
app.post('/api/auth/login', applySdkMiddlewares, async (req:any,res)=>{
  // middleware pode setar req.sdkDecision
  if (req.sdkDecision?.decision === 'block') return res.status(403).json(req.sdkDecision);
  if (req.sdkDecision?.decision === 'challenge') return res.status(202).json(req.sdkDecision);

  const parsed = LoginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  // fake auth
  await pool.query('INSERT INTO users(email,password) VALUES ($1,$2) ON CONFLICT (email) DO NOTHING', [parsed.data.email, '***']);
  res.json({ ok: true, user: { email: parsed.data.email } });
});

const CheckoutSchema = z.object({ email: z.string().email(), amount: z.number().min(1) });
app.post('/api/checkout', applySdkMiddlewares, async (req:any,res)=>{
  if (req.sdkDecision?.decision === 'block') return res.status(403).json(req.sdkDecision);
  if (req.sdkDecision?.decision === 'challenge') return res.status(202).json(req.sdkDecision);
  const parsed = CheckoutSchema.safeParse({ email: req.body?.email, amount: Number(req.body?.amount) });
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  await pool.query('INSERT INTO orders(user_email, amount) VALUES ($1,$2)', [parsed.data.email, parsed.data.amount]);
  res.json({ ok: true, order: { amount: parsed.data.amount } });
});

app.get('/api/logs', async (_req,res)=>{
  const { rows } = await pool.query('SELECT * FROM sdk_events ORDER BY id DESC LIMIT 100');
  res.json(rows);
});

app.listen(port, ()=> console.log(`[backend] http://localhost:${port}`));
