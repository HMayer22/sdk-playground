// Carrega SDKs web (se existirem) dinamicamente
export async function loadSdks(endpoint){
  const sdks = [];
  try {
    const mod = await import('../../sdks/risk-sdk/web/index.ts');
    if (mod && mod.initSDK){
      const sdk = mod.initSDK({ endpoint });
      sdks.push(sdk);
    }
  } catch {}
  return sdks;
}
