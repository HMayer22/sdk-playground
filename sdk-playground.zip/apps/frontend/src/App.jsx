import React, { useEffect, useState } from 'react'
import { loadSdks } from './sdkLoader'

const API = 'http://localhost:4001'

export default function App(){
  const [email, setEmail] = useState('user@example.com')
  const [amount, setAmount] = useState(120)
  const [logs, setLogs] = useState([])
  const [sdks, setSdks] = useState([])

  useEffect(()=>{
    loadSdks(API).then(s=>{
      setSdks(s)
      s.forEach(sdk => sdk.autoCollect && sdk.autoCollect())
    })
  }, [])

  async function login(){
    const ctx = { sessionId: 'sess_'+Math.random().toString(36).slice(2) }
    const body = { email, password: '123', context: ctx }
    const res = await fetch(API+'/api/auth/login', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) })
    const data = await res.json()
    alert('Login: ' + JSON.stringify(data))
  }

  async function checkout(){
    const body = { email, amount: Number(amount) }
    const res = await fetch(API+'/api/checkout', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) })
    const data = await res.json()
    alert('Checkout: ' + JSON.stringify(data))
  }

  async function refreshLogs(){
    const res = await fetch(API+'/api/logs')
    setLogs(await res.json())
  }

  return (
    <div style={{fontFamily:'sans-serif', padding:20, display:'grid', gap:16}}>
      <h1>SDK Playground Store</h1>
      <section style={{display:'grid', gap:8}}>
        <label>Email <input value={email} onChange={e=>setEmail(e.target.value)} /></label>
        <div style={{display:'flex', gap:8}}>
          <button onClick={login}>Login</button>
          <input type="number" value={amount} onChange={e=>setAmount(e.target.value)} />
          <button onClick={checkout}>Checkout</button>
          <button onClick={refreshLogs}>Logs</button>
        </div>
      </section>
      <section>
        <h3>Eventos Recentes</h3>
        <pre style={{background:'#f5f5f5', padding:10, maxHeight:300, overflow:'auto'}}>{JSON.stringify(logs, null, 2)}</pre>
      </section>
      <section>
        <h3>SDKs carregados</h3>
        <pre>{sdks.length ? sdks.map(()=>'- sdk web').join('\n') : 'nenhum'}</pre>
      </section>
    </div>
  )
}
